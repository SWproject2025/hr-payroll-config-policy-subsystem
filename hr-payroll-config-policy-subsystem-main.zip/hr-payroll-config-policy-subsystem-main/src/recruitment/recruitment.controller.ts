import { Controller } from '@nestjs/common';

@Controller('recruitment')
export class RecruitmentController {}
