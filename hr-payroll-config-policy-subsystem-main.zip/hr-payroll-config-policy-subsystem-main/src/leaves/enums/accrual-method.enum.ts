export enum AccrualMethod {
  MONTHLY = 'monthly',
  YEARLY = 'yearly',
  PER_TERM = 'per-term',
}