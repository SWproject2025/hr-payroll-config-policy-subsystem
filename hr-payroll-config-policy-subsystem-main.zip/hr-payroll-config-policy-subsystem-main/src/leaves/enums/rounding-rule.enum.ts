export enum RoundingRule {
  NONE = 'none',
  ROUND = 'round',
  ROUND_UP = 'round_up',
  ROUND_DOWN = 'round_down',
}
