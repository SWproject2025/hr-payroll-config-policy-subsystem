export enum AttachmentType {
  MEDICAL = 'medical',
  DOCUMENT = 'document',
  OTHER = 'other',
}
