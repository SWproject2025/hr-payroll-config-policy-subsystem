export enum AdjustmentType {
  ADD = 'add',
  DEDUCT = 'deduct',
  ENCASHMENT = 'encashment',
}
