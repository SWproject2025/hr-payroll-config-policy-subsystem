import { Controller } from '@nestjs/common';

@Controller('leaves')
export class LeavesController {}
