import { Controller } from '@nestjs/common';

@Controller('time-management')
export class TimeManagementController {}
