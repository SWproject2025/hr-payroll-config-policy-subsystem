import { Controller } from '@nestjs/common';

@Controller('payroll-tracking')
export class PayrollTrackingController {}
