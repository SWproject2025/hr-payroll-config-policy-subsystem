import { Controller } from '@nestjs/common';

@Controller('payroll-execution')
export class PayrollExecutionController {}
