import { Controller } from '@nestjs/common';

@Controller('performance')
export class PerformanceController {}
