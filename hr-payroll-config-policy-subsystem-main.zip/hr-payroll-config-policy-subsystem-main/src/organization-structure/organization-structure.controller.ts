import { Controller } from '@nestjs/common';

@Controller('organization-structure')
export class OrganizationStructureController {}
