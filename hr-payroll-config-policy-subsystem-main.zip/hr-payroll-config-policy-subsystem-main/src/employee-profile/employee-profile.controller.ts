import {
    Controller,
    Post,
    Param,
    UseGuards,
  } from '@nestjs/common';
  import { Roles } from '../auth/roles.decorator';  
  import { RolesGuard } from '../auth/roles.guard'; 
  import { JwtAuthGuard } from '../auth/jwt-auth.guard';
  import { Role } from '../auth/role.enum';        
  import { EmployeeProfileService } from './employee-profile.service';
  
  @Controller('employee-profile')
  export class EmployeeProfileController {
    constructor(private readonly employeeProfileService: EmployeeProfileService) {}
  
    @Post(':id/accept')
    @Roles(Role.ADMIN, Role.HR_MANAGER)
    @UseGuards(JwtAuthGuard, RolesGuard)
    async acceptEmployeeProfile(@Param('id') id: string) {
      return this.employeeProfileService.acceptEmployeeProfile(id);
    }
  
    @Post(':id/reject')
    @Roles(Role.ADMIN, Role.HR_MANAGER)
    @UseGuards(JwtAuthGuard, RolesGuard)
    async rejectEmployeeProfile(@Param('id') id: string) {
      return this.employeeProfileService.rejectEmployeeProfile(id);
    }
  }
  